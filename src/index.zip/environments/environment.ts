export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "",
    authDomain: "",
    projectId: "",
    storageBucket: "",
    messagingSenderId: "",
    appId: "",
    measurementId: ""
  },
  openAIConfig: {
    apiKey: "",
    apiUrl: ''
  },
  googleConfig: {
    apiKey: "",
    cseId: "",
  }
};